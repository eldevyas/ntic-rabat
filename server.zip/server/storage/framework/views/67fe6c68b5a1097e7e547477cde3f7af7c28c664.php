<!DOCTYPE html>
<html>

<head>
    <title>Password Reset</title>
</head>

<body>
    <h1>Password Reset</h1>
    <p>Use the following link to reset your password:</p>
    <a href="<?php echo e(url('http://localhost:3000/auth/reset-password/?token=' . $token)); ?>">Reset
        Password</a>
</body>

</html>
<?php /**PATH C:\Users\hp\Documents\GitHub\NTIC-Rabat\server\resources\views/mail/forgetPasswordEmail.blade.php ENDPATH**/ ?>